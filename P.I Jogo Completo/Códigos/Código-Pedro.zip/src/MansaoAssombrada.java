import javax.swing.JOptionPane;

public class MansaoAssombrada {

    public static void main(String[] args) {

        int escolha1, escolha2, escolha3, escolha4;

        JOptionPane.showMessageDialog(null,
                "====================================\n"
              + "      RPG - A MANSÃO ASSOMBRADA\n"
              + "====================================\n\n"
              + "Você acorda em uma cama sem se lembrar de nada.\n"
              + "Está tudo escuro e a única parte iluminada é a janela.\n"
              + "Ao olhar para fora, percebe que está no último andar\n"
              + "de uma mansão gigantesca.");

        escolha1 = Integer.parseInt(JOptionPane.showInputDialog(
                "O QUE VOCÊ FAZ?\n"
              + "1 - Tentar gritar chamando alguém\n"
              + "2 - Tentar fugir pela janela"));

        if (escolha1 == 1) {

            JOptionPane.showMessageDialog(null,
                    "Você grita procurando alguém.\n"
                  + "Depois de alguns segundos, escuta uma voz\n"
                  + "vindo de um dos quartos daquele andar.\n"
                  + "A voz parece familiar... muito familiar.");

        } else if (escolha1 == 2) {

            JOptionPane.showMessageDialog(null,
                    "Você vai até a janela.\n"
                  + "Percebe que está a mais de 30 metros do chão.\n"
                  + "Por sorte, encontra uma corda velha no quarto.");

        } else {
            JOptionPane.showMessageDialog(null, "Escolha inválida.");
            return;
        }

        if (escolha1 == 1) {
            escolha2 = Integer.parseInt(JOptionPane.showInputDialog(
                    "O QUE VOCÊ FAZ?\n"
                  + "1 - Ir até o quarto de onde vem a voz\n"
                  + "2 - Tentar conversar com a pessoa"));
        } else {
            escolha2 = Integer.parseInt(JOptionPane.showInputDialog(
                    "O QUE VOCÊ FAZ?\n"
                  + "1 - Amarrar a corda no armário\n"
                  + "2 - Amarrar a corda na cama"));
        }

        if (escolha1 == 1 && escolha2 == 1) {

            JOptionPane.showMessageDialog(null,
                    "Você caminha até o quarto.\n"
                  + "Tropeça em um pedaço de madeira.\n"
                  + "A porta se abre lentamente.");

        } else if (escolha1 == 1 && escolha2 == 2) {

            JOptionPane.showMessageDialog(null,
                    "Você conversa com a pessoa.\n"
                  + "Ela abre a porta.\n"
                  + "Ao se encontrarem, ambos ficam espantados.\n"
                  + "Vocês têm a mesma voz e quase a mesma aparência.");

        } else if (escolha1 == 2 && escolha2 == 1) {

            JOptionPane.showMessageDialog(null,
                    "O armário cai e quebra tudo.\n"
                  + "Debaixo da cama, um livro brilhante aparece.");

        } else if (escolha1 == 2 && escolha2 == 2) {

            JOptionPane.showMessageDialog(null,
                    "A cama quebra e você volta ao quarto.\n"
                  + "Debaixo da cama há um livro estranho brilhando.");

        } else {
            JOptionPane.showMessageDialog(null, "Escolha inválida.");
            return;
        }

        JOptionPane.showMessageDialog(null,
                "Você abre o livro.\n"
              + "Ele possui apenas uma página.\n"
              + "Nela está escrito:\n"
              + "\"Só se deve confiar em uma frase,\n"
              + "pois a outra levará à perdição.\"");

        escolha3 = Integer.parseInt(JOptionPane.showInputDialog(
                "O QUE VOCÊ FAZ?\n"
              + "1 - Ler a primeira frase\n"
              + "2 - Ler a segunda frase"));

        if (escolha3 == 1) {

            JOptionPane.showMessageDialog(null,
                    "A frase diz:\n"
                  + "\"A saída está no porão, mas não vá sozinho.\"");

        } else if (escolha3 == 2) {

            JOptionPane.showMessageDialog(null,
                    "A frase diz:\n"
                  + "\"Confie apenas em si mesmo e salte.\"");

        } else {
            JOptionPane.showMessageDialog(null, "Escolha inválida.");
            return;
        }

        escolha4 = Integer.parseInt(JOptionPane.showInputDialog(
                "No fim do corredor, uma porta enorme aparece.\n"
              + "A pessoa misteriosa diz:\n"
              + "\"Só um de nós é real.\"\n\n"
              + "O QUE VOCÊ FAZ?\n"
              + "1 - Abrir a porta com a pessoa\n"
              + "2 - Fugir sozinho"));

        if (escolha4 == 1) {

            JOptionPane.showMessageDialog(null,
                    "Vocês atravessam a porta.\n"
                  + "Lá fora, a pessoa desaparece.\n"
                  + "Você percebe que era seu reflexo.\n\n"
                  + "FINAL 1: O OUTRO VOCÊ");

        } else if (escolha4 == 2) {

            JOptionPane.showMessageDialog(null,
                    "Você foge sozinho.\n"
                  + "Ao abrir o livro novamente, lê:\n"
                  + "\"Você escolheu a frase errada.\"\n"
                  + "Tudo escurece.\n\n"
                  + "FINAL 2: LOOP ETERNO");

        } else {
            JOptionPane.showMessageDialog(null, "Escolha inválida.");
        }
    }
}