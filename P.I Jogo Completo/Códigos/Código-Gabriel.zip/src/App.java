import  java.util.Scanner;
public class App {
    public static void main(String[] args) throws Exception {
        
        Scanner leitor = new Scanner(System.in);

        System.out.println("MANSÃO ASSOMBRADA");

  
 // System.out.println("Nesse jogo você é um rapaz comum que acorda em um quarto de uma mansão assombrada sem lembrar porque e nem como você chegou ali.\r\n" + //
      //      "\r\n" + //
      //      "Você acorda em uma cama sem se lembrar de nada, está tudo escuro e a única parte iluminada é a janela, ao olhar para fora você percebe que está no último andar de uma mansão gigantesca.\n\n OQUE VOÇÊ FAZ?\r\n" + //
      //      "");
  
  //escolha 3 (explorar o andar)



  String texto1 = "Você decide explorar o andar.\n\n" + 
            "O chão de madeira faz uns barulhinhos enquanto você anda, tipo aqueles rangidos que dão um leve arrepio. \n" +
            "O corredor é comprido, meio apertado, e a luz é fraca, uma lâmpada lá no fundo fica piscando, deixando tudo ainda mais estranho.\n\n" + 
            "À esquerda, tem uma porta meio aberta, de lá vem um som baixo, difícil de entender, parece alguém respirando ou sussurrando.\n" + 
            "À direita, o corredor continua até uma escada em espiral que desce pra um breu total. Sério, não dá pra ver nada lá embaixo.\n\n" + 
            "Do nada, BAM!\na porta do quarto que você tava se fecha sozinha atrás de você.\n\n" + 
            "Agora não tem muito pra onde correr...\n\n"; 
            
  String texto2 = "Sem aviso, tudo ao seu redor fica instável.\n\n" + 
                "As paredes, o chão… parece que a mansão inteira tá se mexendo.\n\n" + 
                "Você perde o equilíbrio e cai.\n\n" + 
                "Por alguns segundos, só escuridão.\n\n" + 
                "Quando você abre os olhos de novo…\n\n" + 
                "Você não tá mais no mesmo lugar.\n\n" + 
                "Agora você tá em um corredor diferente.\n\n" + 
                "Mais largo. Mais antigo. E muito mais estranho.\n\n" + 
                "No fim dele, tem duas coisas:\n\n";
                
   String texto3 = "De repente, um barulho alto ecoa pela mansão inteira.\n\n" + 
              "BOOM\n\n" + 
              "As luzes apagam por completo.\n\n" + 
              "Você tenta se orientar, mas não dá pra ver nada.\n\n" + 
              "Aí, algo segura seu braço.\n\n" + 
              "Forte.\n\n" + 
              "Gelado.\n\n" + 
              "Você tenta puxar… mas não consegue.\n\n" + 
              "E então—\n\n" + 
              "Tudo some.\n\n" + 
              "Silêncio.\n\n" + 
              "Quando você abre os olhos de novo…\n\n" + 
              "Você tá sentado em uma cadeira.\n\n" + 
              "Amarrado.\n\n" + 
              "Em uma sala pequena, iluminada por uma luz fraca no teto.\r\n" + 
              "Na sua frente…\n\n" + 
              "Tem uma mesa.\n\n" + 
              "E em cima dela:\n\n" + 
              "- Um gravador antigo\n\n" + 
              " -  E uma faca\n\n" + 
              "E o gravador… começa a tocar sozinho.\n\n";

    String texto4 = "Sem aviso, a luz apaga.\r\n" + 
                "A cadeira cai com tudo no chão.\r\n" + 
                "Você tenta reagir, mas algo te puxa com força.\r\n" + 
                "Escuridão total.\r\n" + 
                "Silêncio.\r\n" + 
                "…\r\n" + 
                "Quando você abre os olhos de novo…\r\n" + 
                "Você tá de pé.\r\n" + 
                "Não tá mais amarrado.\r\n" + 
                "A sala sumiu.\r\n" + 
                "Agora você tá em um corredor longo, com várias portas dos dois lados.\r\n" + 
                "Todas iguais.\r\n" + 
                "Todas fechadas.\r\n" + 
                "Menos uma.\r\n" + 
                "No final do corredor.\r\n" + 
                "Ela tá aberta.\r\n" + 
                "E dessa vez…\r\n" + 
                "não parece uma escolha.\r\n" + 
                "Parece que você tem que ir até lá.\r\n";

    String textoFinal = "Você toma sua decisão. Seja indo direto até a porta no fim ou tentando outra antes, no final não faz diferença. Todas levam ao mesmo lugar.\n\n" + 
                "Assim que você encosta na maçaneta, ela abre sozinha. Lá dentro não tem nada, só escuridão. Não é um quarto… é vazio. Mesmo assim, algo te puxa pra dentro. Você tenta parar, mas não consegue.\n\n" + 
                "Quando percebe, já está lá dentro. A porta atrás de você se fecha com um click. Você tenta andar, mas não sente o chão. Tenta falar… nenhum som sai.\n\n" + 
                "Então uma luz fraca aparece à frente, crescendo devagar. Ela revela uma sala. A mesma sala. A cadeira, a mesa, o gravador, a faca.\n\n" + 
                "E alguém ali.\n\n" + 
                "Amarrado. Se debatendo.\n\n" + 
                "É você.\n\n" + 
                "O gravador liga sozinho: \"O próximo já chegou.\"\n\n" + 
                "Você tenta reagir, mas seu corpo não responde. Só consegue assistir enquanto a luz apaga.\n\n" + 
                "A última coisa que você vê… é você mesmo olhando pra você.\n\n" + 
                "E aí você entende.\n\n" + 
                "Você não está preso na casa.\n\n" + 
                "Você faz parte dela agora.\n\n";
                
                
                    

  
System.out.println(texto1);

while (true) 
    {
        System.out.println("O que você faria?\n\nA = Entrar na sala de onde vem o som estranho\nB = Ou descer a escada em espiral e ver o que tem lá embaixo " );
        String escolhaTexto1 = leitor.nextLine();

                    String a1 = "Você decide empurrar a porta devagar.\n\n" + 
                            "Ela abre com um rangido chato… lá dentro tá escuro, mas dá pra ver umas coisas jogadas pelo chão. Parece um quarto abandonado há anos.\n\n" + 
                            "O som que você ouviu fica mais claro agora… é tipo uma respiração pesada.\n\n" + 
                            "Você dá mais um passo.\n\n" + 
                            "De repente, para.\n\n" + 
                            "Silêncio total.\n\n" + 
                            "Aí… bem no seu ouvido:\n\n" + 
                            "“Você não devia estar aqui…”\n\n" + 
                            "Você vira rápido... Não tem ninguém.\n\n" +
                            "Mas a porta atrás de você bate com tudo.\n\n" + 
                            "E o chão começa a tremer levemente.";

                    String b1 = "Você resolve descer a escada.\n\n" + 
                            "Cada passo faz um eco estranho, como se o lugar fosse muito maior do que parece.\n\n" + 
                            "Quanto mais você desce, mais escuro fica… até que a luz de cima praticamente some.\n\n" + 
                            "No meio da descida…\n\n" + 
                            "Você escuta algo.\n\n" + 
                            "Passos.\n\n" + 
                            "Mas não são os seus.\n\n" + 
                            "Eles vêm de baixo… subindo na sua direção.\n\n" + 
                            "Você para.\n\n" +
                            "Os passos param também.\n\n" + 
                            "Aí, bem perto de você, uma voz baixa:\n\n" + 
                            "“Você não devia estar aqui…”\n\n" + 
                            "Do nada, a escada dá um estalo alto.\n\n" + 
                            "E tudo começa a tremer.\n\n"; 

                        
    if (escolhaTexto1.equalsIgnoreCase("a")) {System.out.println(a1);
    break;}

    else if (escolhaTexto1.equalsIgnoreCase("b")) {System.out.println(b1);
    break;}

    else {System.out.println("escolha invalida\n\n");}

}


 System.out.println(texto2);
  
 while (true) 
    { 
        System.out.println("A - Chegar mais perto da porta...\n\nB - Seguir o som...");
        String escolhaTexto2 = leitor.nextLine();

        String a2 = "Você chega mais perto da porta.\r\n" + 
            "Os símbolos são estranhos… parecem riscados com pressa, como se alguém estivesse tentando avisar alguma coisa.\r\n" + 
            "Você encosta a mão.\r\n" + 
            "Na hora… sente um frio absurdo subindo pelo braço.\r\n" + 
            "A porta não abre.\r\n" + 
            "Mas os símbolos começam a tremer levemente… como se estivessem vivos.\r\n" + 
            "Do nada, você escuta um clique atrás de você.\r\n" + 
            "Quando vira…\r\n" + 
            "Tem alguém no fim do corredor.\r\n" + 
            "Parado.\n\n" + 
            "Sem se mexer.\n\n" + 
            "Só olhando.\n\n" + 
            "A luz pisca.\n\n" + 
            "E… ele some.\n\n" + 
            "Logo depois, a porta faz um barulho pesado… como se tivesse destrancado sozinha.\r\n";

        String b2 = "Você decide seguir o som.\r\n" + 
                "Cada passo parece mais arriscado que o outro.\r\n" + 
                "O barulho vai ficando mais alto… CLANG… CLANG… CLANG…\r\n" + 
                "Parece algo batendo em metal.\r\n" + 
                 "Você chega mais perto e vê uma porta meio aberta.\r\n" + 
                 "Dentro, algo se mexe.\r\n" + 
                 "Você tenta olhar melhor…\r\n" + 
                 "E o barulho para.\r\n" + 
                 "Silêncio.\r\n" + 
                 "Aí… atrás de você:\r\n" + 
                 "CLANG\r\n" + //
                 "Você vira rápido.\r\n" + 
                 "Nada.\r\n" + 
                 "Quando olha pra frente de novo…\r\n" + 
                 "A porta tá totalmente aberta agora.\r\n" + 
                 "E lá dentro… tá escuro demais pra ver.\r\n" + 
                 "Mas dá pra sentir que tem alguma coisa ali.\r\n";

                 
    if (escolhaTexto2.equalsIgnoreCase("a")) {System.out.println(a2);
    break;}

    else if (escolhaTexto2.equalsIgnoreCase("b")) {System.out.println(b2);
    break;}

    else {System.out.println("escola invalida");}

 }

  
   System.out.println(texto3);

   while (true) {

    System.out.println("A - Tentar alcançar\n\nB - Ouvir o gravador" );
    String escolhaTexto3 = leitor.nextLine();

String a3 = "Você força o corpo pra frente, tentando alcançar a faca.\r\n" + 
        "A cadeira arrasta no chão, fazendo um barulho seco.\r\n" + 
        "Mais um pouco…\r\n" + 
        "Você estica os dedos ao máximo e consegue empurrar a faca da mesa.\r\n" + 
        "Ela cai no chão.\r\n" + 
        "Droga.\r\n" + 
        "Você se inclina ainda mais, quase perdendo o equilíbrio, e consegue pegar a faca com dificuldade.\r\n" + 
        "Começa a serrar a corda devagar… tentando não fazer barulho.\r\n" + 
        "O gravador continua rodando.\r\n" + 
        "Mas agora…\r\n" + 
        "Sem som nenhum.\r\n" + 
        "Silêncio total.\r\n" +
        "Você para por um segundo.\r\n" + 
        "Algo tá errado.\r\n" + 
        "A corda começa a ceder…\r\n" + 
        "E então—\r\n" + 
        "Você sente uma presença atrás de você.\r\n" + 
        "Bem perto.\r\n" + 
        "Parada.\r\n" + 
        "Observando.\r\n";

String b3 = "Você para de se mexer.\r\n" + 
            "O gravador chia… e continua:\r\n" + 
            "\"Rápido… você precisa sair dessa sala.\"\r\n" + 
            "Sua respiração fica pesada.\r\n" + 
            "\"Ela não pode te ver solto.\"\r\n" + 
            "A luz pisca forte.\r\n" + 
            "\"Se você fizer barulho… já era.\"\r\n" + 
            "O gravador falha.\r\n" + 
            "Por um segundo… silêncio.\r\n" + 
            "E então, bem baixo:\r\n" + 
            "\"Ela tá atrás de você.\"\r\n" + 
            "O gravador desliga.\r\n" + 
            "Na mesma hora…\r\n" + 
            "Você sente.\r\n" + 
            "Uma respiração fria no seu pescoço.\r\n"; 

        if (escolhaTexto3.equalsIgnoreCase("a")) {System.out.println(a3);
            break;
        }

        else if (escolhaTexto3.equalsIgnoreCase("b")) {System.out.println(b3);
         break;   
        }

        else {System.out.println("resposta invalida");}

    }

System.out.println(texto4);

while (true) 
    {
    System.out.println("A - Ir direto até a porta aberta no fim do corredor\n\nB - Tentar abrir uma das outras portas fechadas antes de chegar lá");
    String escolhaTexto4 = leitor.nextLine();

    if (escolhaTexto4.equalsIgnoreCase("a")) {System.out.println(textoFinal);
break;
    }
      
    else if (escolhaTexto4.equalsIgnoreCase("b")){ System.out.println(textoFinal);
break;
    }

    else {System.out.println("resposta invalida");}

}

    }
                
        }

