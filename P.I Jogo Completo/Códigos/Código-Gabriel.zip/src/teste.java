import javax.swing.JOptionPane;

public class teste {
    public static void main(String[] args) {

        JOptionPane.showMessageDialog(null, "MANSÃO ASSOMBRADA");

        String texto1 = "Você decide explorar o andar.\n\n" + 
            "O chão de madeira faz uns barulhinhos enquanto você anda, tipo aqueles rangidos que dão um leve arrepio.\n" +
            "O corredor é comprido, meio apertado, e a luz é fraca, uma lâmpada lá no fundo fica piscando.\n\n" + 
            "À esquerda, tem uma porta meio aberta, de lá vem um som baixo, parece alguém respirando.\n" + 
            "À direita, o corredor continua até uma escada em espiral que desce pra um breu total.\n\n" + 
            "BAM!\nA porta atrás de você se fecha sozinha.\n\nAgora não tem muito pra onde correr...\n\n"; 
            
        String texto2 = "Sem aviso, tudo ao seu redor fica instável.\n\n" + 
            "As paredes parecem se mexer.\n\n" + 
            "Você perde o equilíbrio e cai.\n\n" + 
            "Quando abre os olhos...\n\n" + 
            "Você está em outro corredor.\n\n"; 
                
        String texto3 = "BOOM\n\n" + 
            "As luzes apagam.\n\n" + 
            "Algo segura seu braço.\n\n" + 
            "Quando você acorda...\n\n" + 
            "Você está amarrado em uma cadeira.\n\n" + 
            "Na mesa:\n- Um gravador\n- Uma faca\n\n" + 
            "O gravador começa a tocar sozinho...\n\n";

        String texto4 = "A luz apaga.\n\n" + 
            "Você acorda em um corredor cheio de portas.\n\n" + 
            "Uma delas está aberta no final.\n\n";

        String textoFinal = "Você toma sua decisão...\n\n" + 
            "A porta abre sozinha.\n\n" + 
            "Você entra.\n\n" + 
            "Lá dentro...\n\n" + 
            "Tem alguém amarrado.\n\n" + 
            "É você.\n\n" + 
            "O gravador liga:\n\"O próximo já chegou.\"\n\n" + 
            "Você entende...\n\n" + 
            "Você faz parte da mansão agora.\n\n";

        JOptionPane.showMessageDialog(null, texto1);

        // ESCOLHA 1
        while (true) {
            String escolhaTexto1 = JOptionPane.showInputDialog(
                "O que você faria?\n\nA = Entrar na sala\nB = Descer a escada"
            );

            if (escolhaTexto1 == null) System.exit(0);

            String a1 = "Você entra na sala...\nAlgo te observa.";
            String b1 = "Você desce a escada...\nAlgo sobe até você.";

            if (escolhaTexto1.equalsIgnoreCase("a")) {
                JOptionPane.showMessageDialog(null, a1);
                break;
            } 
            else if (escolhaTexto1.equalsIgnoreCase("b")) {
                JOptionPane.showMessageDialog(null, b1);
                break;
            } 
            else {
                JOptionPane.showMessageDialog(null, "Você escolheu algo que não existe…\nA mansão não perdoa erros.");
            }
        }

        JOptionPane.showMessageDialog(null, texto2);

        // ESCOLHA 2
        while (true) {
            String escolhaTexto2 = JOptionPane.showInputDialog(
                "A = Chegar perto da porta\nB = Seguir o som"
            );

            if (escolhaTexto2 == null) System.exit(0);

            String a2 = "Você encosta na porta...\nAlgo aparece atrás de você.";
            String b2 = "Você segue o som...\nAlgo te observa no escuro.";

            if (escolhaTexto2.equalsIgnoreCase("a")) {
                JOptionPane.showMessageDialog(null, a2);
                break;
            } 
            else if (escolhaTexto2.equalsIgnoreCase("b")) {
                JOptionPane.showMessageDialog(null, b2);
                break;
            } 
            else {
                JOptionPane.showMessageDialog(null, "Escolha inválida!");
            }
        }

        JOptionPane.showMessageDialog(null, texto3);

        // ESCOLHA 3
        while (true) {
            String escolhaTexto3 = JOptionPane.showInputDialog(
                "A = Tentar pegar a faca\nB = Ouvir o gravador"
            );

            if (escolhaTexto3 == null) System.exit(0);

            String a3 = "Você tenta se soltar...\nAlgo está atrás de você.";
            String b3 = "O gravador diz:\n\"Ela está atrás de você.\"";

            if (escolhaTexto3.equalsIgnoreCase("a")) {
                JOptionPane.showMessageDialog(null, a3);
                break;
            } 
            else if (escolhaTexto3.equalsIgnoreCase("b")) {
                JOptionPane.showMessageDialog(null, b3);
                break;
            } 
            else {
                JOptionPane.showMessageDialog(null, "Resposta inválida!");
            }
        }

        JOptionPane.showMessageDialog(null, texto4);

        // ESCOLHA FINAL
        while (true) {
            String escolhaTexto4 = JOptionPane.showInputDialog(
                "A = Ir até a porta\nB = Tentar outra"
            );

            if (escolhaTexto4 == null) System.exit(0);

            if (escolhaTexto4.equalsIgnoreCase("a") || escolhaTexto4.equalsIgnoreCase("b")) {
                JOptionPane.showMessageDialog(null, textoFinal);
                break;
            } 
            else {
                JOptionPane.showMessageDialog(null, "Resposta inválida!");
            }
        }
    }
}
