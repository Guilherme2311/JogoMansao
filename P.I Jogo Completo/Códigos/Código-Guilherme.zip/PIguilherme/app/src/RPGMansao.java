import java.util.Scanner;

public class RPGMansao {

    public static void main(String[] args) {

        Scanner ler = new Scanner(System.in);

        int escolha1, escolha2, escolha3, escolha4;

        System.out.println("====================================");
        System.out.println("      RPG - A MANSÃO ESQUECIDA");
        System.out.println("====================================\n");

        System.out.println("Você se levanta devagar.");
        System.out.println("O chão de madeira range sob seus pés.");
        System.out.println("O quarto está coberto de poeira.");
        System.out.println("Na parede há um retrato antigo com os rostos riscados.\n");

        System.out.println("O QUE VOCÊ FAZ?");
        System.out.println("1 - Abrir a porta e investigar o corredor.");
        System.out.println("2 - Examinar melhor o quarto.");
        System.out.print("Escolha: ");
        escolha1 = ler.nextInt();

        if (escolha1 == 1) {

            System.out.println("\nVocê abre a porta lentamente.");
            System.out.println("O corredor parece interminável.");
            System.out.println("Você ouve algo se movendo atrás de você.");
            System.out.println("Assustado, volta rapidamente para o quarto.");

        } else if (escolha1 == 2) {

            System.out.println("\nVocê procura pistas pelo quarto.");
            System.out.println("Debaixo da cama encontra uma chave enferrujada.");
            System.out.println("Passos lentos ecoam do lado de fora.");
            System.out.println("Você corre até a porta.");

        } else {

            System.out.println("\nEscolha inválida.");
            return;
        }

        System.out.println("\n====================================\n");

        System.out.println("No corredor há uma vela acesa e um bilhete:");
        System.out.println("\"Se quer sair vivo, desça até o salão principal antes da meia-noite.\"");
        System.out.println("O relógio toca...");
        System.out.println("DONG... DONG... DONG...\n");

        System.out.println("O QUE VOCÊ FAZ?");
        System.out.println("1 - Pegar a vela e seguir pelo corredor.");
        System.out.println("2 - Procurar outro caminho pela mansão.");
        System.out.print("Escolha: ");
        escolha2 = ler.nextInt();

        if (escolha2 == 1) {

            System.out.println("\nVocê pega a vela.");
            System.out.println("A chama ilumina retratos rasgados.");
            System.out.println("Você encontra uma grande escadaria.");
            System.out.println("Ao lado dela há uma porta entreaberta.");

        } else if (escolha2 == 2) {

            System.out.println("\nVocê ignora a vela.");
            System.out.println("Depois de caminhar no escuro, encontra a mesma escadaria.");
            System.out.println("Ao lado dela há uma porta misteriosa.");

        } else {

            System.out.println("\nEscolha inválida.");
            return;
        }

        System.out.println("\n====================================\n");

        System.out.println("O relógio toca novamente.");
        System.out.println("Agora faltam sete badaladas.\n");

        System.out.println("O QUE VOCÊ FAZ?");
        System.out.println("1 - Entrar na sala ao lado da escadaria.");
        System.out.println("2 - Descer imediatamente as escadas.");
        System.out.print("Escolha: ");
        escolha3 = ler.nextInt();

        if (escolha3 == 1) {

            System.out.println("\nVocê entra na sala.");
            System.out.println("É uma biblioteca antiga.");
            System.out.println("Uma cadeira de balanço se move sozinha.");
            System.out.println("Em um diário está escrito:");
            System.out.println("\"Só quem lembrar seu nome pode sair.\"");
            System.out.println("No espelho, uma sombra aparece atrás de você.");
            System.out.println("Você corre para a escadaria.");

        } else if (escolha3 == 2) {

            System.out.println("\nVocê desce correndo as escadas.");
            System.out.println("Os degraus parecem infinitos.");
            System.out.println("Ao passar por um espelho rachado,");
            System.out.println("seu reflexo sussurra:");
            System.out.println("\"Lembre-se do seu nome...\"");

        } else {

            System.out.println("\nEscolha inválida.");
            return;
        }

        System.out.println("\n====================================\n");

        System.out.println("Você chega ao salão principal.");
        System.out.println("Há uma enorme porta de ferro.");
        System.out.println("Na frente dela está uma mulher vestida de preto.");
        System.out.println("Ela diz:");
        System.out.println("\"Diga seu nome... ou fique aqui para sempre.\"");
        System.out.println("Faltam apenas quatro badaladas.\n");

        System.out.println("O QUE VOCÊ FAZ?");
        System.out.println("1 - Tentar lembrar seu nome.");
        System.out.println("2 - Correr para a porta.");
        System.out.print("Escolha: ");
        escolha4 = ler.nextInt();

        if (escolha4 == 1) {

            System.out.println("\nVocê fecha os olhos.");
            System.out.println("Memórias começam a surgir.");
            System.out.println("Então você se lembra:");
            System.out.println("\"Lucas...\"");
            System.out.println("A mulher recua lentamente.");
            System.out.println("A porta de ferro se abre.");

        } else if (escolha4 == 2) {

            System.out.println("\nVocê corre em direção à porta.");
            System.out.println("Tudo fica mais pesado.");
            System.out.println("No último instante, uma memória explode em sua mente:");
            System.out.println("\"Lucas!\"");
            System.out.println("A mulher desaparece.");
            System.out.println("A porta se abre imediatamente.");

        } else {

            System.out.println("\nEscolha inválida.");
            return;
        }

        System.out.println("\n====================================");
        System.out.println("               FINAL");
        System.out.println("====================================\n");

        System.out.println("Você sai da mansão e respira o ar frio da madrugada.");
        System.out.println("A construção começa a desmoronar.");
        System.out.println("No bolso do casaco há uma fotografia antiga.");
        System.out.println("Nela, você está ao lado da mulher de preto.");
        System.out.println("\"Lucas e Helena, para sempre.\"");
        System.out.println("\nAs memórias retornam.");
        System.out.println("Helena era sua noiva.");
        System.out.println("A maldição finalmente foi quebrada.");
        System.out.println("\nEnquanto o sol nasce, você sussurra:");
        System.out.println("\"Adeus, Helena.\"");
        System.out.println("\nFIM DO JOGO.");

    }
}
