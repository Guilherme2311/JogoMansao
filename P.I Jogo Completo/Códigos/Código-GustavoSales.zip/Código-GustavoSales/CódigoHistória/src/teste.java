import javax.swing.JOptionPane;

public class teste {

    public static void main(String[] args) {

        JOptionPane.showMessageDialog(null, "<b>MANSÃO ASSOMBRADA</b>");

        String texto1 = "A pessoa acordou no quarto de uma mansão assombrada.\n\n" +

            "O teto era alto demais.\n" +

            "As paredes tinham marcas escuras, como se algo tivesse sido arrastado por elas durante anos.\n\n" +

            "A única luz vinha de um abajur velho piscando no canto do quarto.\n\n" +

            "Do lado de fora da porta, dava pra ouvir passos lentos andando pelo corredor.\n\n" +

            "E então...\n\n" +

            "TOC.\nTOC.\nTOC.\n\n" +

            "Alguém bateu na porta.\n\n";

        String texto2 = "Seja abrindo a porta ou se escondendo, o resultado é o mesmo.\n\n" +

            "A maçaneta gira sozinha.\n\n" +

            "A porta abre lentamente.\n\n" +

            "Mas não tem ninguém lá fora.\n\n" +

            "Só um corredor comprido e escuro.\n\n" +

            "No chão, existe uma trilha de pegadas molhadas levando até o final do corredor.\n\n" +

            "E no teto... algo parece se mover rápido demais pra enxergar direito.\n\n" +

            "O ar fica gelado.\n\n" +

            "Uma voz baixa sussurra:\n\n" +

            "\"Você demorou...\"\n\n";

        String texto3 = "Não importa o caminho escolhido.\n\n" +

            "As luzes começam a piscar violentamente.\n\n" +

            "O corredor parece ficar maior a cada passo.\n\n" +

            "As paredes rangem.\n\n" +

            "As portas ao redor começam a abrir e fechar sozinhas.\n\n" +

            "BAM.\n\nBAM.\n\nBAM.\n\n" +

            "Então uma delas para aberta.\n\n" +

            "Lá dentro existe uma sala cheia de relógios antigos.\n\n" +

            "Todos estão parados exatamente no mesmo horário.\n\n" +

            "03:17.\n\n" +

            "No centro da sala existe uma cadeira virada de costas.\n\n" +

            "E alguém está sentado nela.\n\n" +

            "Imóvel.\n\n";

        String texto4 = "A cadeira começa a girar devagar.\n\n" +

            "Bem devagar.\n\n" +

            "Até revelar o rosto da figura.\n\n" +

            "É a própria pessoa.\n\n" +

            "Mas com os olhos completamente pretos.\n\n" +

            "O sorriso dela é estranho... grande demais.\n\n" +

            "Então a versão sentada começa a falar junto com você.\n\n" +

            "Mesmas palavras.\n\n" +

            "Mesma voz.\n\n" +

            "Mesmo tempo.\n\n" +

            "As luzes apagam.\n\n" +

            "Quando voltam...\n\n" +

            "Você não está mais na sala.\n\n" +

            "Agora está em um porão úmido, cheio de canos enferrujados.\n\n" +

            "No fundo existe uma porta vermelha entreaberta.\n\n" +

            "E atrás dela dá pra ouvir alguém chorando.\n\n";

        String textoFinal = "Os dois caminhos levam até a mesma porta.\n\n" +

            "Ela bate atrás de você sozinha.\n\n" +

            "O choro para imediatamente.\n\n" +

            "Silêncio absoluto.\n\n" +

            "Na parede existe uma frase escrita com tinta preta:\n\n" +

            "\"Quem entra aqui nunca acorda de verdade.\"\n\n" +

            "Atrás de você, alguém respira perto do seu ouvido.\n\n" +

            "Você vira rapidamente.\n\n" +

            "Não tem ninguém.\n\n" +

            "Mas no chão existe uma foto antiga.\n\n" +

            "Nela, aparece você.\n\n" +

            "Parado na frente da mansão.\n\n" +

            "Datada de muitos anos atrás.\n\n" +

            "Muito antes de você nascer.\n\n" +

            "Então todas as luzes se apagam pela última vez.\n\n" +

            "...\n\n" +

            "Quando abre os olhos, você está novamente no quarto onde tudo começou.\n\n" +

            "Deitado na cama.\n\n" +

            "O abajur piscando.\n\n" +

            "Os passos no corredor.\n\n" +

            "E as três batidas na porta.\n\n" +

            "TOC.\n\nTOC.\n\nTOC.";

        JOptionPane.showMessageDialog(null, texto1);

        // ESCOLHA 1
        while (true) {

            String escolhaTexto1 = JOptionPane.showInputDialog(

                "O que ela faz?\n\nA = Abrir a porta devagar\nB = Se esconder atrás da cama"

            );

            if (escolhaTexto1 == null) System.exit(0);

            String a1 = "Você abre a porta lentamente...\nO corredor parece infinito.";
            String b1 = "Você se esconde atrás da cama...\nAlgo passa pela porta.";

            if (escolhaTexto1.equalsIgnoreCase("a")) {

                JOptionPane.showMessageDialog(null, a1);
                break;

            } else if (escolhaTexto1.equalsIgnoreCase("b")) {

                JOptionPane.showMessageDialog(null, b1);
                break;

            } else {

                JOptionPane.showMessageDialog(null, "Escolha inválida!");

            }
        }

        JOptionPane.showMessageDialog(null, texto2);

        // ESCOLHA 2
        while (true) {

            String escolhaTexto2 = JOptionPane.showInputDialog(

                "O que ela faz?\n\nA = Seguir as pegadas\nB = Ignorar as pegadas e andar pelo corredor"

            );

            if (escolhaTexto2 == null) System.exit(0);

            String a2 = "Você segue as pegadas...\nO corredor fica cada vez mais escuro.";
            String b2 = "Você ignora as pegadas...\nAs luzes piscam atrás de você.";

            if (escolhaTexto2.equalsIgnoreCase("a")) {

                JOptionPane.showMessageDialog(null, a2);
                break;

            } else if (escolhaTexto2.equalsIgnoreCase("b")) {

                JOptionPane.showMessageDialog(null, b2);
                break;

            } else {

                JOptionPane.showMessageDialog(null, "Escolha inválida!");

            }
        }

        JOptionPane.showMessageDialog(null, texto3);

        // ESCOLHA 3
        while (true) {

            String escolhaTexto3 = JOptionPane.showInputDialog(

                "O que ela faz?\n\nA = Chegar perto da cadeira\nB = Tentar falar com a pessoa sentada"

            );

            if (escolhaTexto3 == null) System.exit(0);

            String a3 = "Você chega perto da cadeira...\nA figura começa a se mover.";
            String b3 = "Você tenta falar...\nA voz responde igual à sua.";

            if (escolhaTexto3.equalsIgnoreCase("a")) {

                JOptionPane.showMessageDialog(null, a3);
                break;

            } else if (escolhaTexto3.equalsIgnoreCase("b")) {

                JOptionPane.showMessageDialog(null, b3);
                break;

            } else {

                JOptionPane.showMessageDialog(null, "Escolha inválida!");

            }
        }

        JOptionPane.showMessageDialog(null, texto4);

        // ESCOLHA FINAL
        while (true) {

            String escolhaTexto4 = JOptionPane.showInputDialog(

                "O que ela faz?\n\nA = Entrar pela porta vermelha\nB = Tentar fugir pelo porão"

            );

            if (escolhaTexto4 == null) System.exit(0);

            if (escolhaTexto4.equalsIgnoreCase("a") ||
                escolhaTexto4.equalsIgnoreCase("b")) {

                JOptionPane.showMessageDialog(null, textoFinal);
                break;

            } else {

                JOptionPane.showMessageDialog(null, "Escolha inválida!");

            }
        }
    }
}