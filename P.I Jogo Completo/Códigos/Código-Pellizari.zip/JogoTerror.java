import java.util.Scanner;

// ============================================================
//  JOGO DE TERROR - VOCÊ DECIDE GRITAR CHAMANDO ALGUÉM
//  Autor: Gabriel Pellizari Araujo
//  Conceitos usados: funções, vetores, laço de repetição,
//                    estrutura condicional
// ============================================================

public class JogoTerror {

    // -----------------------------------------------------------
    // VETOR GLOBAL: guarda o histórico de escolhas do jogador
    // -----------------------------------------------------------
    static String[] historicoEscolhas = new String[10];
    static int totalEscolhas = 0;

    static Scanner teclado = new Scanner(System.in);

    // ===========================================================
    //  FUNÇÃO PRINCIPAL - ponto de entrada do jogo
    // ===========================================================
    public static void main(String[] args) {

        boolean jogarNovamente = true;

        // LAÇO DE REPETIÇÃO: permite jogar várias vezes
        while (jogarNovamente) {

            // Zera o histórico a cada nova partida
            totalEscolhas = 0;
            for (int i = 0; i < historicoEscolhas.length; i++) {
                historicoEscolhas[i] = "";
            }

            exibirIntro();
            texto1();
            texto2();
            texto3();
            texto4();
            exibirFinal();
            exibirHistorico();

            jogarNovamente = perguntarJogarNovamente();
        }

        System.out.println("\n  Obrigado por jogar. Que a mansão não te esqueça...");
        System.out.println("  [ FIM ]");
        teclado.close();
    }

    // ===========================================================
    //  FUNÇÃO: exibe a introdução do jogo
    // ===========================================================
    static void exibirIntro() {
        limparTela();
        System.out.println("╔══════════════════════════════════════════════════════════╗");
        System.out.println("║         VOCÊ DECIDE GRITAR CHAMANDO ALGUÉM               ║");
        System.out.println("║              Um jogo de terror interativo                 ║");
        System.out.println("╚══════════════════════════════════════════════════════════╝");
        System.out.println();
        System.out.println("  Você acorda em uma cama sem se lembrar de nada.");
        System.out.println("  Está tudo escuro. A única parte iluminada é a janela.");
        System.out.println("  Ao olhar para fora, você percebe que está no último");
        System.out.println("  andar de uma mansão gigantesca.");
        System.out.println();
        System.out.println("  Você abre a boca.");
        System.out.println("  E grita.");
        System.out.println();
        pausar();
    }

    // ===========================================================
    //  FUNÇÃO: Texto 1 - o grito e a resposta misteriosa
    // ===========================================================
    static void texto1() {
        limparTela();
        System.out.println("══════════════════════════════════════");
        System.out.println("  TEXTO 1");
        System.out.println("══════════════════════════════════════");
        System.out.println();
        System.out.println("  A voz sai mais fraca do que você esperava —");
        System.out.println("  rouca, como se sua garganta estivesse seca há horas.");
        System.out.println();
        System.out.println("  O silêncio que vem depois parece ainda mais pesado.");
        System.out.println();
        System.out.println("  Mas então...");
        System.out.println();
        System.out.println("  Uma resposta.");
        System.out.println();
        System.out.println("  Baixa. Abafada. Saindo de um quarto no corredor à frente.");
        System.out.println("  A voz é estranha... familiar demais pra ser de um estranho.");
        System.out.println();
        System.out.println("  Ela fala de novo — e dessa vez dá pra ouvir claramente:");
        System.out.println();
        System.out.println("  \"Me ajuda... por favor.\"");
        System.out.println();

        // ESTRUTURA CONDICIONAL: valida a escolha do jogador
        String escolha = pedirEscolha(
            "  A - Ir até o quarto em silêncio",
            "  B - Tentar conversar de onde você está"
        );

        // Salva no vetor de histórico
        registrarEscolha("Texto 1: " + escolha);

        // ESTRUTURA CONDICIONAL: decide qual caminho seguir
        if (escolha.equals("A")) {
            texto1EscolhaA();
        } else {
            texto1EscolhaB();
        }
    }

    // ===========================================================
    //  FUNÇÃO: Escolha A do Texto 1
    // ===========================================================
    static void texto1EscolhaA() {
        limparTela();
        System.out.println("  [ ESCOLHA A - Ir em silêncio ]");
        System.out.println();
        System.out.println("  Você decide ir devagar. Sem fazer barulho.");
        System.out.println("  Cada passo no corredor é uma tensão nova.");
        System.out.println("  O chão range levemente. Você prende a respiração.");
        System.out.println();
        System.out.println("  A voz parou.");
        System.out.println();
        System.out.println("  Você chega mais perto da porta... ela está entreaberta.");
        System.out.println("  Uma fresta de luz saindo de dentro.");
        System.out.println();
        System.out.println("  Você espia pelo vão.");
        System.out.println("  Lá dentro tem uma figura sentada de costas. Imóvel.");
        System.out.println();
        System.out.println("  Você dá um passo pra dentro...");
        System.out.println();
        System.out.println("  CRACK.");
        System.out.println();
        System.out.println("  O chão trai você.");
        System.out.println("  A figura se levanta devagar. E vira.");
        System.out.println();
        System.out.println("  Você congela.");
        System.out.println();
        System.out.println("  O rosto dela...");
        System.out.println();
        System.out.println("  É igual ao seu.");
        System.out.println();
        pausar();
    }

    // ===========================================================
    //  FUNÇÃO: Escolha B do Texto 1
    // ===========================================================
    static void texto1EscolhaB() {
        limparTela();
        System.out.println("  [ ESCOLHA B - Conversar de longe ]");
        System.out.println();
        System.out.println("  Você fica parado e grita de novo:");
        System.out.println("  \"Ei! Quem tá aí? Você tá bem?\"");
        System.out.println();
        System.out.println("  Silêncio por alguns segundos.");
        System.out.println();
        System.out.println("  Depois, a voz responde — mais clara agora:");
        System.out.println("  \"Não entra aqui. Fica onde você tá.\"");
        System.out.println();
        System.out.println("  Você franze a testa.");
        System.out.println("  \"Por quê? O que aconteceu?\"");
        System.out.println();
        System.out.println("  Uma pausa longa.");
        System.out.println();
        System.out.println("  \"Porque... ela ainda tá aqui.\"");
        System.out.println();
        System.out.println("  Você sente um frio percorrer sua espinha.");
        System.out.println("  \"Quem?\"");
        System.out.println();
        System.out.println("  A voz não responde.");
        System.out.println("  Mas você ouve um barulho diferente agora...");
        System.out.println();
        System.out.println("  De trás de você.");
        System.out.println();
        pausar();
    }

    // ===========================================================
    //  FUNÇÃO: Texto 2 - a sala sem janelas
    // ===========================================================
    static void texto2() {
        limparTela();
        System.out.println("══════════════════════════════════════");
        System.out.println("  TEXTO 2");
        System.out.println("══════════════════════════════════════");
        System.out.println();
        System.out.println("  As luzes do corredor piscam três vezes.");
        System.out.println("  E apagam.");
        System.out.println();
        System.out.println("  Escuridão total.");
        System.out.println();
        System.out.println("  O chão treme. Não muito — só o suficiente.");
        System.out.println("  Você tenta achar a parede com as mãos...");
        System.out.println();
        System.out.println("  E toca em algo.");
        System.out.println("  Não é a parede.");
        System.out.println("  É uma mão.");
        System.out.println();
        System.out.println("  Ela aperta a sua com força. E puxa.");
        System.out.println();
        System.out.println("  Quando a luz volta — fraca, tremida —");
        System.out.println("  você tá em uma sala pequena. Sem janelas.");
        System.out.println();
        System.out.println("  No centro: uma mesa velha. Em cima dela:");
        System.out.println("    - Uma lanterna apagada");
        System.out.println("    - E um espelho coberto por um pano preto");
        System.out.println();

        String escolha = pedirEscolha(
            "  A - Pegar a lanterna e iluminar o ambiente",
            "  B - Retirar o pano do espelho"
        );

        registrarEscolha("Texto 2: " + escolha);

        if (escolha.equals("A")) {
            texto2EscolhaA();
        } else {
            texto2EscolhaB();
        }
    }

    // ===========================================================
    //  FUNÇÃO: Escolha A do Texto 2
    // ===========================================================
    static void texto2EscolhaA() {
        limparTela();
        System.out.println("  [ ESCOLHA A - Pegar a lanterna ]");
        System.out.println();
        System.out.println("  Você pega a lanterna.");
        System.out.println("  Ela liga de primeira — a luz corta o escuro da sala.");
        System.out.println();
        System.out.println("  E revela as paredes.");
        System.out.println();
        System.out.println("  Cobertas de marcações.");
        System.out.println("  Riscos. Números. Nomes.");
        System.out.println();
        System.out.println("  Você aponta a lanterna mais perto e lê um dos nomes.");
        System.out.println();
        System.out.println("  O seu.");
        System.out.println();
        System.out.println("  Escrito ali. Com o que parece ser carvão.");
        System.out.println("  Abaixo do seu nome, uma frase:");
        System.out.println();
        System.out.println("  \"O que entra não sai.\"");
        System.out.println();
        System.out.println("  Você recua um passo.");
        System.out.println("  E a lanterna apaga.");
        System.out.println();
        pausar();
    }

    // ===========================================================
    //  FUNÇÃO: Escolha B do Texto 2
    // ===========================================================
    static void texto2EscolhaB() {
        limparTela();
        System.out.println("  [ ESCOLHA B - O espelho ]");
        System.out.println();
        System.out.println("  Você agarra o pano e puxa de uma vez.");
        System.out.println("  O espelho aparece — grande, antigo, moldura rachada.");
        System.out.println();
        System.out.println("  Você olha pro reflexo.");
        System.out.println("  Tá tudo certo no começo.");
        System.out.println("  Você. A sala. A mesa.");
        System.out.println();
        System.out.println("  Mas então...");
        System.out.println();
        System.out.println("  O reflexo pisca.");
        System.out.println("  Você não piscou.");
        System.out.println();
        System.out.println("  Você olha mais fixo, coração acelerado.");
        System.out.println("  O reflexo levanta a mão devagar.");
        System.out.println("  Você não moveu a mão.");
        System.out.println();
        System.out.println("  E então o reflexo coloca o dedo nos lábios.");
        System.out.println();
        System.out.println("  \"Shh.\"");
        System.out.println();
        pausar();
    }

    // ===========================================================
    //  FUNÇÃO: Texto 3 - a porta e o que está do outro lado
    // ===========================================================
    static void texto3() {
        limparTela();
        System.out.println("══════════════════════════════════════");
        System.out.println("  TEXTO 3");
        System.out.println("══════════════════════════════════════");
        System.out.println();
        System.out.println("  Algo bate na porta da sala.");
        System.out.println();
        System.out.println("  Uma vez.");
        System.out.println("  Duas.");
        System.out.println("  Três.");
        System.out.println();
        System.out.println("  E para.");
        System.out.println();
        System.out.println("  Silêncio pesado.");
        System.out.println("  Você mal respira.");
        System.out.println();
        System.out.println("  A maçaneta começa a girar — devagar — de fora pra dentro.");
        System.out.println("  A porta abre um centímetro... dois... para.");
        System.out.println();
        System.out.println("  Nada aparece.");
        System.out.println("  Mas você sente que tem algo do outro lado. Esperando.");
        System.out.println();
        System.out.println("  No chão perto dos seus pés você nota:");
        System.out.println("    - Uma chave enferrujada");
        System.out.println("    - E um bilhete dobrado");
        System.out.println();

        String escolha = pedirEscolha(
            "  A - Pegar a chave e tentar trancar a porta",
            "  B - Abrir o bilhete"
        );

        registrarEscolha("Texto 3: " + escolha);

        if (escolha.equals("A")) {
            texto3EscolhaA();
        } else {
            texto3EscolhaB();
        }
    }

    // ===========================================================
    //  FUNÇÃO: Escolha A do Texto 3
    // ===========================================================
    static void texto3EscolhaA() {
        limparTela();
        System.out.println("  [ ESCOLHA A - A chave ]");
        System.out.println();
        System.out.println("  Você pega a chave e vai até a porta em passos rápidos.");
        System.out.println("  Você encaixa a chave na fechadura.");
        System.out.println();
        System.out.println("  Ela gira.");
        System.out.println();
        System.out.println("  CLACK.");
        System.out.println();
        System.out.println("  A porta tá trancada.");
        System.out.println("  Você recua, aliviado por um segundo.");
        System.out.println();
        System.out.println("  Mas aí a porta começa a tremer.");
        System.out.println("  Algo está empurrando do outro lado.");
        System.out.println("  Com força.");
        System.out.println();
        System.out.println("  A chave cai da fechadura sozinha.");
        System.out.println();
        System.out.println("  E a porta abre de vez.");
        System.out.println();
        pausar();
    }

    // ===========================================================
    //  FUNÇÃO: Escolha B do Texto 3
    // ===========================================================
    static void texto3EscolhaB() {
        limparTela();
        System.out.println("  [ ESCOLHA B - O bilhete ]");
        System.out.println();
        System.out.println("  Você pega o bilhete com dedos trêmulos e desdobra.");
        System.out.println("  A letra é irregular, apressada:");
        System.out.println();
        System.out.println("  \"Não olha pra ela.");
        System.out.println("   Não fala com ela.");
        System.out.println("   Não deixa ela te tocar.\"");
        System.out.println();
        System.out.println("  Você lê de novo. E de novo.");
        System.out.println();
        System.out.println("  A porta abre mais um pouco.");
        System.out.println("  Você não olha.");
        System.out.println("  Você ouve passos lentos entrando na sala.");
        System.out.println("  Você fixa o olhar no bilhete.");
        System.out.println();
        System.out.println("  Não olha.");
        System.out.println("  Não olha.");
        System.out.println();
        System.out.println("  Uma voz suave, quase gentil:");
        System.out.println();
        System.out.println("  \"Por que você não olha pra mim?\"");
        System.out.println();
        pausar();
    }

    // ===========================================================
    //  FUNÇÃO: Texto 4 - o corredor da decisão final
    // ===========================================================
    static void texto4() {
        limparTela();
        System.out.println("══════════════════════════════════════");
        System.out.println("  TEXTO 4");
        System.out.println("══════════════════════════════════════");
        System.out.println();
        System.out.println("  Tudo acontece de uma vez.");
        System.out.println("  Um barulho ensurdecedor.");
        System.out.println("  Escuridão.");
        System.out.println();
        System.out.println("  E então — nada.");
        System.out.println();
        System.out.println("  ...");
        System.out.println();
        System.out.println("  Quando você abre os olhos, está de pé.");
        System.out.println("  Num corredor diferente. As paredes são mais altas.");
        System.out.println("  As portas são mais estreitas.");
        System.out.println();
        System.out.println("  E no fim do corredor — tem luz.");
        System.out.println("  Uma luz quente, quase convidativa.");
        System.out.println();
        System.out.println("  Mas no meio do caminho:");
        System.out.println("  Uma escada à sua direita, descendo pro andar de baixo.");
        System.out.println("  Escura. Sem fim visível.");
        System.out.println();

        String escolha = pedirEscolha(
            "  A - Seguir em frente até a luz",
            "  B - Descer a escada primeiro"
        );

        registrarEscolha("Texto 4: " + escolha);

        if (escolha.equals("A")) {
            texto4EscolhaA();
        } else {
            texto4EscolhaB();
        }
    }

    // ===========================================================
    //  FUNÇÃO: Escolha A do Texto 4
    // ===========================================================
    static void texto4EscolhaA() {
        limparTela();
        System.out.println("  [ ESCOLHA A - Seguir a luz ]");
        System.out.println();
        System.out.println("  Você vai em direção à luz.");
        System.out.println("  Ela parece próxima.");
        System.out.println("  Mas não chega.");
        System.out.println();
        System.out.println("  Você anda. E anda. E anda.");
        System.out.println("  A luz nunca parece mais perto.");
        System.out.println();
        System.out.println("  E de repente...");
        System.out.println("  ela apaga.");
        System.out.println();
        System.out.println("  E você percebe onde você está.");
        System.out.println("  De volta. No quarto. Na cama.");
        System.out.println("  A janela iluminada. Igual ao começo.");
        System.out.println();
        pausar();
    }

    // ===========================================================
    //  FUNÇÃO: Escolha B do Texto 4
    // ===========================================================
    static void texto4EscolhaB() {
        limparTela();
        System.out.println("  [ ESCOLHA B - A escada ]");
        System.out.println();
        System.out.println("  Você começa a descer.");
        System.out.println("  Cada degrau ecoa num lugar que parece enorme demais.");
        System.out.println();
        System.out.println("  Você desce.");
        System.out.println("  E desce.");
        System.out.println("  E desce.");
        System.out.println();
        System.out.println("  Até que o chão some sob seus pés.");
        System.out.println();
        System.out.println("  Escuridão.");
        System.out.println();
        System.out.println("  E quando você abre os olhos de novo...");
        System.out.println("  Você está de volta. No quarto. Na cama.");
        System.out.println("  A janela iluminada. Igual ao começo.");
        System.out.println();
        pausar();
    }

    // ===========================================================
    //  FUNÇÃO: exibe o final da história
    // ===========================================================
    static void exibirFinal() {
        limparTela();
        System.out.println("╔══════════════════════════════════════════════════════════╗");
        System.out.println("║                        F I N A L                         ║");
        System.out.println("╚══════════════════════════════════════════════════════════╝");
        System.out.println();
        System.out.println("  Não importa o que você escolheu.");
        System.out.println("  Todas as escolhas levam ao mesmo lugar.");
        System.out.println();
        System.out.println("  Você está de volta ao quarto onde tudo começou.");
        System.out.println("  A cama. O escuro. A janela iluminada.");
        System.out.println();
        System.out.println("  E então você entende.");
        System.out.println();
        System.out.println("  Não tem saída.");
        System.out.println("  Nunca teve.");
        System.out.println();
        System.out.println("  A mansão não te prendeu quando você entrou.");
        System.out.println("  Ela te prendeu quando você gritou.");
        System.out.println();
        System.out.println("  Porque foi aí que ela soube que você estava aqui.");
        System.out.println("  E aí que ela escolheu você.");
        System.out.println();
        System.out.println("  Do quarto do lado, você ouve uma voz.");
        System.out.println("  Nova. Assustada.");
        System.out.println("  Gritando por ajuda.");
        System.out.println();
        System.out.println("  E você percebe que agora...");
        System.out.println();
        System.out.println("  É você quem vai responder.");
        System.out.println();
        pausar();
    }

    // ===========================================================
    //  FUNÇÃO: exibe o histórico de escolhas do jogador
    //          usa laço de repetição para percorrer o vetor
    // ===========================================================
    static void exibirHistorico() {
        limparTela();
        System.out.println("══════════════════════════════════════");
        System.out.println("  SEU CAMINHO NESTA PARTIDA:");
        System.out.println("══════════════════════════════════════");
        System.out.println();

        // LAÇO DE REPETIÇÃO: percorre o vetor de histórico
        for (int i = 0; i < totalEscolhas; i++) {
            System.out.println("  " + (i + 1) + ". " + historicoEscolhas[i]);
        }

        System.out.println();
        System.out.println("  Total de escolhas feitas: " + totalEscolhas);
        System.out.println();
    }

    // ===========================================================
    //  FUNÇÃO: registra uma escolha no vetor de histórico
    // ===========================================================
    static void registrarEscolha(String escolha) {
        if (totalEscolhas < historicoEscolhas.length) {
            historicoEscolhas[totalEscolhas] = escolha;
            totalEscolhas++;
        }
    }

    // ===========================================================
    //  FUNÇÃO: pede uma escolha A ou B ao jogador
    //          usa laço de repetição para validar entrada
    // ===========================================================
    static String pedirEscolha(String opcaoA, String opcaoB) {
        String entrada = "";

        System.out.println("──────────────────────────────────────");
        System.out.println("  O QUE VOCÊ FAZ?");
        System.out.println(opcaoA);
        System.out.println(opcaoB);
        System.out.println("──────────────────────────────────────");

        // LAÇO DE REPETIÇÃO: repete até receber A ou B válido
        while (!entrada.equals("A") && !entrada.equals("B")) {
            System.out.print("  Digite A ou B: ");
            entrada = teclado.nextLine().trim().toUpperCase();

            // ESTRUTURA CONDICIONAL: avisa se a entrada for inválida
            if (!entrada.equals("A") && !entrada.equals("B")) {
                System.out.println("  Escolha inválida. Digite apenas A ou B.");
            }
        }

        System.out.println();
        return entrada;
    }

    // ===========================================================
    //  FUNÇÃO: pergunta se o jogador quer jogar de novo
    // ===========================================================
    static boolean perguntarJogarNovamente() {
        String resposta = "";

        System.out.println("══════════════════════════════════════");
        System.out.println("  Deseja jogar novamente?");
        System.out.println("  S - Sim");
        System.out.println("  N - Não");
        System.out.println("══════════════════════════════════════");

        // LAÇO DE REPETIÇÃO: valida entrada
        while (!resposta.equals("S") && !resposta.equals("N")) {
            System.out.print("  Digite S ou N: ");
            resposta = teclado.nextLine().trim().toUpperCase();

            if (!resposta.equals("S") && !resposta.equals("N")) {
                System.out.println("  Digite apenas S ou N.");
            }
        }

        return resposta.equals("S");
    }

    // ===========================================================
    //  FUNÇÃO: pausa o jogo esperando o jogador pressionar Enter
    // ===========================================================
    static void pausar() {
        System.out.println("  [ Pressione ENTER para continuar... ]");
        teclado.nextLine();
    }

    // ===========================================================
    //  FUNÇÃO: simula limpar a tela com linhas em branco
    // ===========================================================
    static void limparTela() {
        // LAÇO DE REPETIÇÃO: imprime 40 linhas para "limpar" a tela
        for (int i = 0; i < 40; i++) {
            System.out.println();
        }
    }
}
