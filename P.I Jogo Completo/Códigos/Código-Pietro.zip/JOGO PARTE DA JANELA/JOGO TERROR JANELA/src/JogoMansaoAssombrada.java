import java.util.Scanner;

public class JogoMansaoAssombrada {
    public static void main(String[] args) {
        Scanner scanner = new Scanner(System.in);
        
        System.out.println("=========================");
        System.out.println("BEM-VINDO AO JOGO - MANSÃO ASSOMBRADA");
        System.out.println("=========================");
        System.out.println("\nNesse jogo você é um rapaz comum que acorda em um quarto");
        System.out.println("de uma mansão assombrada sem lembrar porque e nem como");
        System.out.println("você chegou ali.\n");
        
        System.out.println("Pressione ENTER para continuar...");
        scanner.nextLine();
        
        // Primeira escolha - amarrar corda
        System.out.println("\nVocê acorda em uma cama sem se lembrar de nada. Está tudo escuro");
        System.out.println("e a única parte iluminada é a janela. Ao olhar para fora você percebe");
        System.out.println("que está no último andar de uma mansão gigantesca.");
        System.out.println("\nO QUE VOCÊ FAZ?");
        System.out.println("1 - AMARRA A CORDA EM UM ARMÁRIO VELHO");
        System.out.println("2 - AMARRA A CORDA NA CAMA");
        
        int escolha1;
        boolean cordaArmario = false;
        
        while (true) {
            System.out.print("\nDigite sua escolha (1 ou 2): ");
            if (scanner.hasNextInt()) {
                escolha1 = scanner.nextInt();
                scanner.nextLine();
                if (escolha1 == 1 || escolha1 == 2) {
                    break;
                }
            } else {
                scanner.nextLine();
            }
            System.out.println("Escolha inválida! Tente novamente.");
        }
        
        if (escolha1 == 1) {
            System.out.println("\nNo momento que está descendo, a corda faz o armário cair em cima");
            System.out.println("da cama, quebrando tudo. Seu plano de escapar falha, mas algo chama");
            System.out.println("sua atenção… debaixo da cama há um livro brilhante com uma aura estranha.");
            cordaArmario = true;
        } else {
            System.out.println("\nEnquanto desce, a corda fica instável — dois pés da cama quebram.");
            System.out.println("Você sobe de volta frustrado, percebendo que o plano falhou. Ao se virar…");
            System.out.println("vê um livro brilhante diferente de tudo que já viu.");
            cordaArmario = false;
        }
        
        System.out.println("\nPressione ENTER para continuar...");
        scanner.nextLine();
        
        // Segunda escolha - luz ou escuridão
        System.out.println("\nCheio de curiosidade e confusão, você abre o livro. Ele possui apenas uma página.");
        System.out.println("Na frente está escrito:");
        System.out.println("\"Desça as escadas e siga a luz, pois ela te guiará para fora.\"");
        System.out.println("No verso está escrito:");
        System.out.println("\"Evite a luz e caminhe pela escuridão, pois ela revela a verdade.\"");
        System.out.println("Uma observação está escrita no rodapé:");
        System.out.println("\"Confie em apenas uma frase. A outra levará à perdição.\"");
        System.out.println("\nO QUE VOCÊ FAZ?");
        System.out.println("1 - SEGUE A LUZ PELAS ESCADAS");
        System.out.println("2 - EVITA A LUZ E CAMINHA PELA ESCURIDÃO");
        
        int escolha2;
        
        while (true) {
            System.out.print("\nDigite sua escolha (1 ou 2): ");
            if (scanner.hasNextInt()) {
                escolha2 = scanner.nextInt();
                scanner.nextLine();
                if (escolha2 == 1 || escolha2 == 2) {
                    break;
                }
            } else {
                scanner.nextLine();
            }
            System.out.println("Escolha inválida! Tente novamente.");
        }
        
        if (escolha2 == 1) {
            System.out.println("\nVocê abre a porta e encontra um corredor iluminado por velas.");
            System.out.println("A luz no fim das escadas parece te chamar.");
        } else {
            System.out.println("\nVocê decide ignorar a luz e caminha pela escuridão, guiando-se pelas paredes frias.");
        }
        
        System.out.println("\nPressione ENTER para continuar...");
        scanner.nextLine();
        
        // Terceira escolha - chave ou espelho
        System.out.println("\nIndependentemente da escolha, você chega até uma escadaria longa demais…");
        System.out.println("como se não tivesse fim.");
        System.out.println("Ao descer, encontra um grande saguão. No centro, há uma mesa com dois objetos:");
        System.out.println("- Uma chave enferrujada.");
        System.out.println("- Um espelho limpo demais… refletindo algo estranho.");
        System.out.println("\nO QUE VOCÊ FAZ?");
        System.out.println("1 - PEGA A CHAVE ENFERRUJADA");
        System.out.println("2 - PEGA O ESPELHO LIMPO");
        
        int escolha3;
        boolean pegouEspelho = false;
        
        while (true) {
            System.out.print("\nDigite sua escolha (1 ou 2): ");
            if (scanner.hasNextInt()) {
                escolha3 = scanner.nextInt();
                scanner.nextLine();
                if (escolha3 == 1 || escolha3 == 2) {
                    break;
                }
            } else {
                scanner.nextLine();
            }
            System.out.println("Escolha inválida! Tente novamente.");
        }
        
        if (escolha3 == 1) {
            System.out.println("\nAo tocá-la, um frio percorre seu corpo. Parece que algo te tocou de volta.");
            pegouEspelho = false;
        } else {
            System.out.println("\nSeu reflexo atrasa por um instante… e algo nele sorri sem você sorrir.");
            pegouEspelho = true;
        }
        
        System.out.println("\nPressione ENTER para continuar...");
        scanner.nextLine();
        
        // Quarta escolha - esconder ou observar
        System.out.println("\nUm som ecoa.");
        System.out.println("TOC… TOC… TOC…");
        System.out.println("Uma porta no fundo se abre lentamente.");
        System.out.println("\nO QUE VOCÊ FAZ?");
        System.out.println("1 - SE ESCONDE ATRÁS DA MESA");
        System.out.println("2 - FICA PARADO OBSERVANDO");
        
        int escolha4;
        
        while (true) {
            System.out.print("\nDigite sua escolha (1 ou 2): ");
            if (scanner.hasNextInt()) {
                escolha4 = scanner.nextInt();
                scanner.nextLine();
                if (escolha4 == 1 || escolha4 == 2) {
                    break;
                }
            } else {
                scanner.nextLine();
            }
            System.out.println("Escolha inválida! Tente novamente.");
        }
        
        if (escolha4 == 1) {
            System.out.println("\nVocê se esconde. Vê pés pálidos passando lentamente… algo está ali.");
        } else {
            System.out.println("\nUma criatura alta e sem olhos entra… e começa a andar em sua direção.");
        }
        
        System.out.println("\nPressione ENTER para continuar...");
        scanner.nextLine();
        
        // Quinta escolha - porta branca ou preta
        System.out.println("\nSua mente ecoa uma frase:");
        System.out.println("\"Você já esteve aqui antes.\"");
        System.out.println("Tudo treme. A criatura desaparece.");
        System.out.println("Você está agora em um corredor diferente.");
        System.out.println("No fim, duas portas:");
        System.out.println("- Uma branca, limpa.");
        System.out.println("- Uma preta, velha e rachada.");
        System.out.println("\nO QUE VOCÊ FAZ?");
        System.out.println("1 - ENTRA NA PORTA BRANCA");
        System.out.println("2 - ENTRA NA PORTA PRETA");
        
        int escolha5;
        
        while (true) {
            System.out.print("\nDigite sua escolha (1 ou 2): ");
            if (scanner.hasNextInt()) {
                escolha5 = scanner.nextInt();
                scanner.nextLine();
                if (escolha5 == 1 || escolha5 == 2) {
                    break;
                }
            } else {
                scanner.nextLine();
            }
            System.out.println("Escolha inválida! Tente novamente.");
        }
        
        if (escolha5 == 1) {
            System.out.println("\nUm quarto simples… mas há alguém na cama.");
        } else {
            System.out.println("\nUm quarto deteriorado… com marcas nas paredes… e alguém na cama.");
        }
        
        System.out.println("\nPressione ENTER para continuar...");
        scanner.nextLine();
        
        // Sexta escolha - tocar ou afastar
        System.out.println("\nAo se aproximar, você percebe:");
        System.out.println("É você.");
        System.out.println("Seu próprio corpo está ali, imóvel.");
        System.out.println("Na parede:");
        System.out.println("\"Você nunca saiu daqui.\"");
        System.out.println("\nO QUE VOCÊ FAZ?");
        System.out.println("1 - TOCA NO SEU PRÓPRIO CORPO");
        System.out.println("2 - SE AFASTA ASSUSTADO");
        
        int escolha6;
        
        while (true) {
            System.out.print("\nDigite sua escolha (1 ou 2): ");
            if (scanner.hasNextInt()) {
                escolha6 = scanner.nextInt();
                scanner.nextLine();
                if (escolha6 == 1 || escolha6 == 2) {
                    break;
                }
            } else {
                scanner.nextLine();
            }
            System.out.println("Escolha inválida! Tente novamente.");
        }
        
        if (escolha6 == 1) {
            System.out.println("\nMemórias invadem sua mente violentamente.");
        } else {
            System.out.println("\nVocê tenta fugir… mas memórias começam a surgir mesmo assim.");
        }
        
        System.out.println("\nPressione ENTER para continuar...");
        scanner.nextLine();
        
        // Sétima escolha - aceitar ou quebrar ciclo
        System.out.println("\nVocê se lembra.");
        System.out.println("Você foi trazido para a mansão.");
        System.out.println("Ela se alimenta das pessoas.");
        System.out.println("Você já tentou escapar inúmeras vezes.");
        System.out.println("Tudo… é um ciclo.");
        System.out.println("Uma voz surge novamente:");
        System.out.println("\"Qual versão de você ficará?\"");
        System.out.println("\nO QUE VOCÊ FAZ?");
        System.out.println("1 - ACEITA FICAR NA MANSÃO");
        System.out.println("2 - TENTA QUEBRAR O CICLO");
        
        int escolha7;
        boolean tentouQuebrar = false;
        
        while (true) {
            System.out.print("\nDigite sua escolha (1 ou 2): ");
            if (scanner.hasNextInt()) {
                escolha7 = scanner.nextInt();
                scanner.nextLine();
                if (escolha7 == 1 || escolha7 == 2) {
                    break;
                }
            } else {
                scanner.nextLine();
            }
            System.out.println("Escolha inválida! Tente novamente.");
        }
        
        if (escolha7 == 1) {
            System.out.println("\nVocê aceita.");
            System.out.println("Agora você não sente mais nada.");
            System.out.println("Alguém novo entra na mansão…");
            System.out.println("E você começa a andar em direção a ele.");
            System.out.println("\n" + "=========================");
            System.out.println("FIM — FINAL: O GUARDIÃO DA MANSÃO");
            System.out.println("=========================");
            scanner.close();
            return;
        } else {
            System.out.println("\nVocê se recusa.");
            System.out.println("A mansão começa a tremer violentamente. As paredes racham,");
            System.out.println("o chão se parte… e a criatura surge diante de você, mais distorcida do que nunca.");
            System.out.println("Mas dessa vez… você não foge.");
            System.out.println("Você corre em direção a ela.");
            System.out.println("No impacto—");
            System.out.println("Tudo se quebra.");
            System.out.println("Silêncio.");
            System.out.println("Você abre os olhos.");
            System.out.println("Está do lado de fora da mansão.");
            System.out.println("O sol bate no seu rosto.");
            System.out.println("Você respira… profundamente.");
            System.out.println("Mas algo está errado.");
            System.out.println("No seu bolso… o espelho ainda está.");
            System.out.println("E no reflexo…");
            System.out.println("A criatura continua lá.");
            System.out.println("Ela não ficou na mansão.");
            System.out.println("Ela veio com você.");
            tentouQuebrar = true;
        }
        
        System.out.println("\nPressione ENTER para continuar...");
        scanner.nextLine();
        
        // Oitava escolha - quebrar ou observar espelho
        System.out.println("\nO ar fica pesado novamente. O céu escurece. O espelho vibra em sua mão.");
        System.out.println("Uma voz ecoa:");
        System.out.println("\"Você não quebrou o ciclo… você o trouxe com você.\"");
        System.out.println("O chão começa a desaparecer.");
        System.out.println("\nO QUE VOCÊ FAZ?");
        System.out.println("1 - QUEBRA O ESPELHO NO CHÃO");
        System.out.println("2 - OBSERVA O ESPELHO COM ATENÇÃO");
        
        int escolha8;
        
        while (true) {
            System.out.print("\nDigite sua escolha (1 ou 2): ");
            if (scanner.hasNextInt()) {
                escolha8 = scanner.nextInt();
                scanner.nextLine();
                if (escolha8 == 1 || escolha8 == 2) {
                    break;
                }
            } else {
                scanner.nextLine();
            }
            System.out.println("Escolha inválida! Tente novamente.");
        }
        
        if (escolha8 == 1) {
            System.out.println("\nEle se estilhaça… mas cada fragmento reflete a criatura.");
            System.out.println("Agora… existem várias.");
        } else {
            System.out.println("\nA criatura não olha para você…");
            System.out.println("Ela olha para algo atrás de você.");
        }
        
        System.out.println("\nPressione ENTER para continuar...");
        scanner.nextLine();
        
        // Nona escolha - enfrentar ou conversar
        System.out.println("\nVocê se vira.");
        System.out.println("E vê…");
        System.out.println("Outra versão de você.");
        System.out.println("Mais fria. Mais sombria. Sorrindo.");
        System.out.println("\"Eu sou a parte que ficou.\"");
        System.out.println("\nO QUE VOCÊ FAZ?");
        System.out.println("1 - ENFRENTA SUA OUTRA VERSÃO");
        System.out.println("2 - TENTA CONVERSAR");
        
        int escolha9;
        
        while (true) {
            System.out.print("\nDigite sua escolha (1 ou 2): ");
            if (scanner.hasNextInt()) {
                escolha9 = scanner.nextInt();
                scanner.nextLine();
                if (escolha9 == 1 || escolha9 == 2) {
                    break;
                }
            } else {
                scanner.nextLine();
            }
            System.out.println("Escolha inválida! Tente novamente.");
        }
        
        if (escolha9 == 1) {
            System.out.println("\nVocê tenta atacar… mas algo te impede.");
        } else {
            System.out.println("\nEla ri.");
            System.out.println("\"Você ainda não entendeu…\"");
        }
        
        System.out.println("\nPressione ENTER para continuar...");
        scanner.nextLine();
        
        // Décima escolha - entrar porta vermelha ou fugir
        System.out.println("\nTudo muda novamente.");
        System.out.println("Você está de volta na mansão.");
        System.out.println("Mas agora ela está viva.");
        System.out.println("No centro… uma porta vermelha pulsante.");
        System.out.println("\nO QUE VOCÊ FAZ?");
        System.out.println("1 - ENTRA NA PORTA VERMELHA");
        System.out.println("2 - TENTA FUGIR");
        
        int escolha10;
        
        while (true) {
            System.out.print("\nDigite sua escolha (1 ou 2): ");
            if (scanner.hasNextInt()) {
                escolha10 = scanner.nextInt();
                scanner.nextLine();
                if (escolha10 == 1 || escolha10 == 2) {
                    break;
                }
            } else {
                scanner.nextLine();
            }
            System.out.println("Escolha inválida! Tente novamente.");
        }
        
        if (escolha10 == 1) {
            System.out.println("\nVocê entra… e encara suas memórias, medos e culpa.");
        } else {
            System.out.println("\nNão há saída.");
            System.out.println("Tudo leva à porta vermelha.");
        }
        
        System.out.println("\nPressione ENTER para continuar...");
        scanner.nextLine();
        
        // Décima primeira escolha - aceitar ou negar
        System.out.println("\nDentro, há uma cadeira e um gravador.");
        System.out.println("Sua própria voz diz:");
        System.out.println("\"Existe uma última escolha… não é sobre fugir.\"");
        System.out.println("No chão:");
        System.out.println("\"ACEITAR TUDO QUE VOCÊ É\"");
        System.out.println("\"NEGAR E LUTAR MAIS UMA VEZ\"");
        System.out.println("\nO QUE VOCÊ FAZ?");
        System.out.println("1 - ACEITA");
        System.out.println("2 - NEGA");
        
        int escolha11;
        
        while (true) {
            System.out.print("\nDigite sua escolha (1 ou 2): ");
            if (scanner.hasNextInt()) {
                escolha11 = scanner.nextInt();
                scanner.nextLine();
                if (escolha11 == 1 || escolha11 == 2) {
                    break;
                }
            } else {
                scanner.nextLine();
            }
            System.out.println("Escolha inválida! Tente novamente.");
        }
        
        if (escolha11 == 1) {
            System.out.println("\nVocê aceita tudo.");
            System.out.println("A criatura desaparece.");
            System.out.println("A mansão começa a sumir.");
        } else {
            System.out.println("\nVocê luta… mas a mansão te envolve.");
        }
        
        System.out.println("\nPressione ENTER para continuar...");
        scanner.nextLine();
        
        // Escolha final - atravessar ou ficar
        System.out.println("\nTudo fica branco.");
        System.out.println("Você abre os olhos em um vazio infinito.");
        System.out.println("Uma voz:");
        System.out.println("\"Agora você é livre… ou faz parte.\"");
        System.out.println("Uma última porta surge.");
        System.out.println("\nO QUE VOCÊ FAZ?");
        System.out.println("1 - ATRAVESSA");
        System.out.println("2 - FICA");
        
        int escolhaFinal;
        
        while (true) {
            System.out.print("\nDigite sua escolha (1 ou 2): ");
            if (scanner.hasNextInt()) {
                escolhaFinal = scanner.nextInt();
                scanner.nextLine();
                if (escolhaFinal == 1 || escolhaFinal == 2) {
                    break;
                }
            } else {
                scanner.nextLine();
            }
            System.out.println("Escolha inválida! Tente novamente.");
        }
        
        System.out.println("\n" + "=".repeat(50));
        
        if (escolhaFinal == 1) {
            System.out.println("\nVocê acorda em um quarto normal.");
            System.out.println("Dessa vez… real.");
            System.out.println("No espelho, só você.");
            System.out.println("\nFIM — FINAL: LIBERTO");
        } else {
            System.out.println("\nVocê permanece.");
            System.out.println("E começa a esquecer quem é.");
            System.out.println("A mansão… nunca precisou existir fisicamente.");
            System.out.println("\nFIM — FINAL: O ETERNO");
        }
        
        System.out.println("=========================");
        
        scanner.close();
    }
}